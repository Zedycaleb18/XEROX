while true
do
echo "Starting QUEEN_ANITA-V2!"
node .
done